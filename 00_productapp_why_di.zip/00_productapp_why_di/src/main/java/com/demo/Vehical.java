package com.demo;

public interface Vehical {
	public void move();
}
